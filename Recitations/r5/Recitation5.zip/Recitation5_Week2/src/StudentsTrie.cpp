#include <fstream>
#include <iostream>
#include <string.h>

#include "StudentsTrie.h"

/* @Author
Student Name: Berat Dalsuna
Student ID: 150200002
E-mail: dalsuna20@itu.edu.tr
Date: 27/12/2021
*/

using namespace std;
int students_number = 0;
string* students = NULL;

TrieNode::TrieNode (const char& digit){
   this->digit = digit;
   for(int i=0; i<MAX_CHILDREN; children[i++] = NULL); 
};

// Construct a StudentsTrie using the records in 'file_name' 
StudentsTrie::StudentsTrie ( const string& file_name  ) { 
    ifstream student_ids_file ( file_name );   // ifstream object for input file
    string current_student_id;

    root = new TrieNode('r');

    if( student_ids_file.is_open() ) {
        for(int i=1; student_ids_file >> current_student_id; i++ ) {
           insert_id(current_student_id); // YOU HAVE TO IMPLEMENT insert_id() METHOD
           students_number++;
        }
        student_ids_file.close();
    }
    else {
        cout << "File: " << file_name << " could NOT be opened!!";
        exit(1);
    }

    students = new string[students_number]; // giving new memory space to students array
    student_ids_file.close();
};

// Insert a student ID into the StudentsTrie 
void StudentsTrie::insert_id ( const string& student_id ) {
    // start from the root node
    TrieNode* curr = root;
    for (int j=0; j < student_id.length(); j++)
    {
        // create a new node if the path doesn't exist
        for(int i=0; i < MAX_CHILDREN; i++){
           if(curr->children[i] == NULL){
              curr->children[i] = new TrieNode(student_id[j]);
              curr = curr->children[i];
              break;
           }
           else if (curr->children[i]->digit == student_id[j]){
              curr = curr->children[i];
              break;
           }


        }
    }
 
}; 

// Print Student IDs in Trie in ascending order 
void StudentsTrie::print_trie(){
   string str;
   display(root, str);

   //sorting the array
   int i = 0;
   while(i!=students_number-1){ 
      if (students[i].compare(students[i+1]) > 0){ //comparing two strings according to lexiographic order
         string tmp = students[i];
         students[i] = students[i+1];
         students[i+1] = tmp;
         i = 0;
      }
      else{
         i++;
      }
   }

   // printing students from students array
   for(int i=0;i<students_number;i++){
      
      if(i==0)
         cout << ' ';

      cout << students[i] << ' ';
      if((i+1) % 10 == 0){
         cout << endl;
         cout << ' ';
      }
   }
   cout << endl;
}

int count = 0;
void StudentsTrie::display(TrieNode* r, string str){ //recursive function traverses over trie and appends str to students array

   if (r->children[0] == NULL){
      str += r->digit;
      students[count] = str;
      count++;
      return;
   }

   for(int i = 0, b = 0; i<MAX_CHILDREN; i++){
      if(r->children[i] != NULL){
         if(r != root && b==0){
            str += r->digit;
            b += 1; //b for not appending same digit every time in recursive calls
         }
         display(r->children[i], str);
      }
   }

}

// StudentsTrie Destructor
StudentsTrie::~StudentsTrie() {
   for (int i=0; i < MAX_CHILDREN; i++){
      if( root->children[i] ) delete root->children[i];
   };
};

